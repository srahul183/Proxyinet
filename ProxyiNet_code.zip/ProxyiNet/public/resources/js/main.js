
// var nodeServer = "127.0.0.1";
const port = 443;
var nodeServer = "192.168.50.180";
var site_hist_key = "proxyinet_site_";

$(document).ready(function () {  
    loadHistorySites();

    loadPageFromHashValue();

    $("#sidebar").mCustomScrollbar({
        theme: "minimal"
    });

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
        $(this).toggleClass('active');
    });

    $(window).on('hashchange', function( e ) {
        console.log( 'hash changed' );
        loadPageFromHashValue();
    });

    /**
     * Once anchor is clicked from hsitory section, we are fetching the corresponding pdf/html document by calling the node web-service.
     */
    $(".history-section").on("click", ".site-link", function (e) {
        e.preventDefault();
        var resulttype = $("#custom-url-form .result-type").find(":selected").val();
        var urlText = $(this).attr("href").split("|")[1];

        var url = "https://" + nodeServer + ":"+port+"/open/" + resulttype + "?q=" + urlText;

        //showing the loading icon above the iframe.
        var old_src = $("#result-frame").attr("src");
        $("#result-frame").attr("src", "");
        $("#result-iframe-div").addClass("show-loading");

        axios({
                url: url,
                method: "GET",
                responseType: 'arraybuffer'
            }).then((response) => {
                let blob = new Blob([response.data], {
                    type: response.headers['content-type']
                });
                let url = window.URL.createObjectURL(blob);

                //Setting the data to iframe.
                $('#result-frame').attr('src', url);

                //Setting the title
                $('#result-title-div').html(urlText);
            })
            .catch(function (error) {
                $("#result-frame").attr("src", old_src);
                alert('Not able the access the url.(' + urlText + ')');
                console.log(error);
            }).then(() => {
                $("#result-iframe-div").removeClass("show-loading");
            });

        return false;
    });

    /**
     * Submitting the custom url and fetching the pdf/html doc by calling the node web-endpoint.
     */
    $("#custom-url-form").submit(function (e) {
        e.preventDefault();

        var urlText = $("#custom-url-form .custom-url-text").val();
        if (urlText.trim() == "") {
            alert("please enter the url to browser.");
            return false;
        }
        
        var pattern = /^((http|https):\/\/)/;
        if(!pattern.test(urlText)) {
            // urlText = "http://" + urlText;
            $("#custom-url-form .custom-url-text").val(urlText);
        }
        
        var resulttype = $("#custom-url-form .result-type").find(":selected").val();
        var url = "https://" + nodeServer + ":"+port+"/open/" + resulttype + "?q=" + urlText;

        var old_src = $("#result-frame").attr("src");
        $("#result-frame").attr("src", "");
        $("#result-iframe-div").addClass("show-loading");

        axios({
                url: url,
                method: "GET",
                responseType: 'arraybuffer'
            }).then((response) => {
                let blob = new Blob([response.data], {
                    type: response.headers['content-type']
                });
                let url = window.URL.createObjectURL(blob);

                //Setting the data to iframe.
                $('#result-frame').attr('src', url);

                //Setting the document title
                $('#result-title-div').html(urlText);

                //Adding the url to the history section
                var isNotExist = valueNotExistsInSessionStorage(urlText);
                if (isNotExist) {
                    var nextCount = 0;
                    if (sessionStorage.proxyinet_sitecount) {
                        nextCount = Number(sessionStorage.proxyinet_sitecount) + 1;
                    } else {
                        nextCount = 1;
                    }
                    sessionStorage.setItem("proxyinet_sitecount", nextCount);
                    sessionStorage.setItem(site_hist_key + nextCount, urlText);

                    //adding the link to history section
                    $(".history-section").append('<li> <a href="' + (site_hist_key + nextCount) + '|' + urlText + '" class="text-sm-left site-link">' + urlText + '</a></li>');
                }
            })
            .catch(function (error) {
                $("#result-frame").attr("src", old_src);
                alert('Not able the access the url.(' + urlText + ')');
                console.log(error);
            })
            .then(() => {
                $("#result-iframe-div").removeClass("show-loading");
            });
        return false;
    });

    //Setting the focus of url textbox
    $(".custom-url-text").focus();
});

/**
 * Load the history section in the UI based on the history details stored sessionStorage object.
 */
function loadHistorySites() {
    var count = 1;
    while (true) {
        if (sessionStorage.getItem(site_hist_key + count)) {
            var urlText = sessionStorage.getItem(site_hist_key + count);
            // $(".history-section").append('<li> <a href="' + (site_hist_key + count)+ '|' + urlText + '" class="text-sm-left site-link">' + urlText + '</a> <span class="icon-remove"></span></li>');
            $(".history-section").append('<li> <a href="' + (site_hist_key + count) + '|' + urlText + '" class="text-sm-left site-link">' + urlText + '</a> </li>');
            count++;
        } else {
            break;
        }
    }
    console.log("sessionStorage.proxyinet_sitecount: " + sessionStorage.proxyinet_sitecount);
}

/**
 * Check if the website url is already present in the sessionStorage, if exists, then no need to add it again, else add the url in sessionStorage.
 * @param {*} urlText url to check
 */
function valueNotExistsInSessionStorage(urlText) {
    var notExist = true;
    $.each(sessionStorage, function (key, value) {
        if (typeof value === 'string') {
            if (urlText.toLowerCase().trim() == value.toLowerCase().trim()) {
                notExist = false;
                return false;
            }
        }
    });
    return notExist;
}

/**
 * Load the page based on hash value
 */
function loadPageFromHashValue(){
    var hash = location.hash.trim();
    console.log("Hash value: "+ hash);

    if(hash.indexOf("#") != -1 && hash.length > 1){
        //Setting the url in textbox and trigger click on browse button
        $(".custom-url-text").val(hash.substring(1, hash.length));
        setTimeout(function(){
            $("#custom-url-form").trigger("submit");
        },1000);
    }

}