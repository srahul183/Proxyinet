#!/bin/sh
#Stopping the docker-compose
docker-compose -f /root/RAVSoft_tools/ProxyiNet/docker-compose.yml down

#Removing all the stopped containers
docker rm $(docker ps -a -q)

#Starting the docker-compose to deploy Proxyinet
docker-compose -f /root/RAVSoft_tools/ProxyiNet/docker-compose.yml up -d

echo "Proxyinet redeployed successfully."