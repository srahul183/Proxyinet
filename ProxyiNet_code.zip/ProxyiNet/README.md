# ProxyiNet

This is repository is to demonstrate the server side rendering capabilities of chrome and puppeteer.

This Web Proxy tool is only intended to use for browsing through the websites and should <b>NOT</b> be used for uploading any kind of data/info to any of the websites.

Build a proxy rendering of web pages content for developers.

## -How to run the tool in local environment: 
    1. server.js is node app which can be run from command line "node .\server.js"
    2. Launch the "http://localhost:80/index.html" in browser.
    
## - How to run the tool in docker containers through Dockerfile: 

    1. Build the docker image based on Dockerfile
        docker build -t proxyinet .
    2. Run the docker image
        docker run -d -p 80:80 --name proxyinet proxyinet
    3. Verify and check if the container is running
        docker ps
        docker container inspect proxyinet
        curl http://[hostname]:80

## - How to deploy the proxyinet in docker containers through Docker-componse.yml file:
    1. docker-compose up --build OR docker-compose up -d
    2. docker-compose down
	
	
## - Cron job to redeploy/restart the proxyinet app after a specific time-interval
We have configured cronjob to automate the application redeployment once in two weeks to avoid OOM errors or other memory related bottlenecks. We are also logging the cronjob event to verify the cronjob triggering.
	
	1. Basic Cronjob related commands:
		- crontab -l	// list configured cron jobs for current user
			>> 0 0 1,15 * * ~/ProxyInet_With_SSL_Updated_23_July/cronjob.sh >> /var/log/cron 2>&1
		
			The above cron job will get executed on 1st and 15th of every month at 00:00am(midnight) time.  
		
		- crontab -e 	// To add/edit the cron job for current user
	
	2. Cronjob logs: Cron job related logs can be found at "/var/log/cron" log file.

	3. Cronjob executes the "cronjob.sh" shell script which removes stopped all the containers and redeploy the proxinet app. Plase refer cronjob.sh for more info.
	
	4. Currently configured cronjob which redeploy the app every 2 weeks, mentioned below:
			0 0 1,15 * * ~/ProxyInet_With_SSL_Updated_23_July/cronjob.sh >> /var/log/cron 2>&1

	5. If required, we can configure the cronjob to run at specified time of a day/week/month/year.
	
		0 0 1 1 *			// yearly
		0 0 * * *			// daily
		0 * * * *			// hourly
		0 0 * * 0			// weekly, every sunday at midnight.
		*/5 * * * *			// every 5 mins
	

	
