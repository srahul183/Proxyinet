const express = require('express');
const app = express();
const { URL } = require('url');

// const hostname = '127.0.0.1';
const hostname = '0.0.0.0';
const port = 4000;


// const serverip = '127.0.0.1'
// const proxy_port = 4000;

const proxy_port = 443;
const serverip = '192.168.50.180'

/**
 * Web-service for generating the pdf document based on the given url.
 */
app.get('/open/pdf', function (req, res) {
  const puppeteer = require('puppeteer');
  (async () => {

    let browser = null;
    let page = null;

    try {

      browser = await puppeteer.launch({
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
      page = await browser.newPage();

      var url = req.query.q;
      console.log("accessing PDF page: "+ url);
        try {
          await page.goto(url, { waitUntil: 'networkidle2' });
        } catch (err) {
          await page.goto("https://duckduckgo.com/?q=" + url, {waitUntil: 'networkidle2'});
        }

      const pageOrigin = new URL(page.url()).origin;
      await page.evaluate(({pageOrigin, serverip, proxy_port}) => {
          let items = document.querySelectorAll('a');
          items.forEach((item) => {
            var actualUrl= item.getAttribute('href');

            //checking the page url
            // var pattern = /^((http|https):\/\/)/;
            var pattern = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
            if(actualUrl != null && actualUrl.match(pattern) == null) {
                actualUrl = pageOrigin + actualUrl;
            }

            item.setAttribute('href', "https://"+serverip+":"+proxy_port+"/index.html#" + actualUrl);
            item.setAttribute('target', "_blank");
          });
      },{pageOrigin, serverip, proxy_port});

      const buffer = await page.pdf({format: 'A4', printBackground: true });

      res.writeHead(200, {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'inline',
        'Content-Length': buffer.length
      });
      res.end(buffer);
    } catch (err) {
      console.error(err);
      return res.status(400).send({
        message: 'Unable to access the url!'
      });
    }
    finally {
      if (page) {
          await page.close();
      }
      if (browser) {
          await browser.close();
      }
    }
  })();
});

/**
 * Web-service for generating the Html document based on the given url.
 */
app.get('/open/html', function (req, res) {
  const puppeteer = require('puppeteer');
  (async () => {

    let browser = null;
    let page = null;

    try {
      browser = await puppeteer.launch({
        args: ['--no-sandbox', '--disable-setuid-sandbox']
      });
      page = await browser.newPage();
      var url = req.query.q;
      console.log("accessing HTML page: "+ url);

      try {
        await page.goto(url, {
          waitUntil: 'networkidle2'
        });
      } catch (err) {
        await page.goto("https://duckduckgo.com/?q=" + url, {
          waitUntil: 'networkidle2'
        });
      }

      const pageOrigin = new URL(page.url()).origin;
      await page.evaluate(({pageOrigin, serverip, proxy_port}) => {
        let items = document.querySelectorAll('a');
        items.forEach((item) => {
          var actualUrl= item.getAttribute('href');

          //checking the page url
          // var pattern = /^((http|https):\/\/)/;
          var pattern = /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
          if (actualUrl != null && actualUrl.match(pattern) == null) {
            actualUrl = pageOrigin + actualUrl;
          }

          item.setAttribute('href', "https://"+serverip+":"+proxy_port+"/index.html#" + actualUrl);
          item.setAttribute('target', "_blank");
        });
      }, {pageOrigin, serverip, proxy_port});

      const html = await page.content();

      res.contentType("text/html");
      res.send(html);
  } catch (err) {
      console.error(err);
      return res.status(400).send({
        message: 'Unable to access the url!'
      });
    }
    finally {
      if (page) {
          await page.close();
      }
      if (browser) {
          await browser.close();
      }
    }
  })();
});

app.use(express.static('public'))
app.listen(port, hostname, () => {
  console.log(`Server running at https://${hostname}:${port}/`);
});
